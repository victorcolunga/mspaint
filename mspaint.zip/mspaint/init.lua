minetest.register_tool("mspaint:sord", {
description = "sord",
inventory_image = "sord.png",
tool_capabilities = {
full_punch_interval = 1.0,
max_drop_level=0,
groupcaps={
snappy={times={[2]=1.4, [3]=0.40}, uses=100000000000, maxlevel=1},
},
damage_groups = {fleshy=-10},
},
sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("mspaint:junsword", {
description = "Jungle Sword",
inventory_image = "junsword.png",
tool_capabilities = {
full_punch_interval = 0.8,
max_drop_level=0,
groupcaps={
snappy={times={[2]=1.4, [3]=0.40}, uses=20, maxlevel=1},
},
damage_groups = {fleshy=5},
},
sound = {breaks = "default_tool_breaks"},
})

minetest.register_craft({
  type = "shapeless",
  output = "mspaint:sord",
  recipe = {"default:dirt"}
})

minetest.register_craft({
  output = "mspaint:junsword",
  recipe = {
    {"", "default:jungleleaves", ""},
    {"", "default:jungleleaves", ""},
    {"", "default:jungletree", ""}
  }


})
